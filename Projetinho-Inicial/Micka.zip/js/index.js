var express = require("express");
var app = express();

// Configura o Express para servir arquivos estáticos da pasta "pages"
app.use(express.static("./pages"));

const port = 3000;

// Redireciona a raiz ("/") para "escolhaConta.html"
app.get("/", (req, res) => {
  res.redirect("/escolhaConta.html");
});

// Rota que responde com "Hello World!" quando acessada
app.get("/hello", (req, res) => {
  res.send("Hello World!");
});

// Inicia o servidor na porta especificada
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
